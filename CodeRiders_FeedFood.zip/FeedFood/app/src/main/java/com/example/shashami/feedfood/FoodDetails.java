package com.example.shashami.feedfood;

/**
 * Created by shashami on 21-Feb-16.
 */
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
public class FoodDetails extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set View to register.xml
        setContentView(R.layout.fooddetails);

        Button pickup=(Button) findViewById(R.id.btnPickup);
        // Listening to Login Screen link
        pickup.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                // Closing registration screen
                // Switching to Login Screen/closing register screen
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getApplicationContext());
                alertDialogBuilder.setMessage("Request Submitted , Shortly Nearest NGO will confirm");
                finish();
            }
        });
    }
}
